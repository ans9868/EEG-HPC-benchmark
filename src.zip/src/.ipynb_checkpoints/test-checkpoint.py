from .preprocess_sets import subPath as getSubPath, participantsInfoPath
# Then you can use these functions
print(getSubPath('001'))
print(participantsInfoPath())
